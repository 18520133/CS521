from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .api.routers import api
from .model.base import models
from .model import engine


def generate_app():
    app = FastAPI()

    models.Base.metadata.create_all(engine)
    app.mount(
        '/static',
        StaticFiles(
            directory="app/backend/jinja/static"),
        name="static")
    app.mount(
        '/raw_dataset1',
        StaticFiles(
            directory="app/backend/dataset/raw_dataset1"),
        name="raw_dataset1")
    app.include_router(api.router)
    return app


app = generate_app()
